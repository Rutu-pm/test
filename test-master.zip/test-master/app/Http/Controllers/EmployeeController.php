<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
use DB;
use Session;

class EmployeeController extends Controller
{
    public function index()
    {
    	$employees = Employee::all();
    	return view('employee',compact('employees'));
    }

    public function create(){
		return View::make('employee');
	}

    public function store(Request $request)
    {
    	$this->validate($request,[
    		'name'=>'required',
    		'email'=>'required|email|unique:employee',
    		'mobileno'=>'required|regex:/[0-9]{9}/|min:10|max:10',
    		'address'=>'max:300',
    		'pincode'=>'required|digits:6',
    		'salary'=>'required|numeric|between:0,99999999.99'
    	]);

    	$data = $request->all();
    	$saveEmployee = Employee::create($data);

    	return back()->with('message','Employee data saved successfully');
    }

    public function show($id)
    {
    	$findemployee = Employee::find($id);
    	return view('showEmployee',compact('findemployee'));
    }

    public function edit($id)
    {
    	$findemployee = Employee::find($id);
    	return view('editEmployee',compact('findemployee'));
    }

    public function Update(Request $request,$id)
    {
    	$this->validate($request,[
    		'name'=>'required',
    		'email'=>'required|email|unique:employee',
    		'mobileno'=>'required|regex:/[0-9]{9}/|min:10|max:10',
    		'address'=>'max:300',
    		'pincode'=>'required|digits:6',
    		'salary'=>'required|numeric|between:0,99999999.99'
    	]);

    	$findemployee = Employee::find($id);
    	$findemployee->name=$request['name'];
    	$findemployee->email=$request['email'];
    	$findemployee->mobileno=$request['mobileno'];
    	$findemployee->address=$request['address'];
    	$findemployee->pincode=$request['pincode'];
    	$findemployee->salary=$request['salary'];
    	$findemployee->save();

    	return redirect('/employee')->with('message','Employee data updated successfully');
    }

    public function destroy($id)
    {
    	Employee::destroy($id);
    	$message='deleted';
    	return json_encode($message);
    }
}
