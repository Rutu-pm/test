<!doctype html>
<html>
   <head>
		<title>Login Successful</title>
   </head>
   <body>
		@if(Session::has('email'))
			<p>Login Successful</p>
			{!! $MyNavBar->asUl() !!}
		@else
		<p>Session expired please login again</p>
			<a href="{{url('/login')}}">Login</a>
		@endif
   </body>
</html>