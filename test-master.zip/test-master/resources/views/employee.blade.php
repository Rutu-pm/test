<!doctype html>
<html>
   <head>
      <title>Add employee</title>
   </head>
   <body>
   @if(Session::has('email'))
      @if(session('message'))    
      <div class="alert">
      <span class="closebtn" onclick="this.parentElement.style.display='none';" style="color: red;font-size: 18px;">&times;</span> 
      <span style="color: red;font-size: 18px;"> {{ session('message')}}.</span>
      </div>
      @endif
      <p>Enter employee details</p>
      <form action="{{url('/employee')}}" method="POST">
         {{ csrf_field() }}
         <label>Name</label>
         <input type="text" name="name">
         <font color="red">
            <?php
               echo($errors->first('name',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Email Id</label>
         <input type="email" name="email">
         <font color="red">
            <?php
               echo($errors->first('email',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Mobile No</label>
         <input type="number" name="mobileno">
         <font color="red">
            <?php
               echo($errors->first('mobileno',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Full Address</label>
         <textarea name="address"></textarea>
         <font color="red">
            <?php
               echo($errors->first('address',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Pincode</label>
         <input type="number" name="pincode">
         <font color="red">
            <?php
               echo($errors->first('pincode',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Salary</label>
         <input type="text" name="salary">
         <font color="red">
            <?php
               echo($errors->first('salary',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <button type="submit" > SAVE</button>
         
      </form>

      <br><br>
      <table class="table table-striped" >
   <thead>
      <tr>
         <td>Id</td>
         <td>Name</td>
         <td>Email</td>
         <td>Mobile No</td>
         <td>Salary</td>
         <td>Action</td>
      </tr>
   </thead>
   <tbody>
      @foreach($employees as $show)
         <tr>
            <td>{{$show->id}}</td>
            <td>{{$show->name}}</td>
            <td>{{$show->email}}</td>
            <td>{{$show->mobileno}}</td>
            <td>{{$show->salary}}</td>
            <td>
               <a href="{{url('/employee/'.$show->id)}}" ><button type="button">Edit</button></a>
               
               <a href="javascript:void(0)" onclick="delete_rows('<?php echo $show->id ?>')"><button type="button">Delete</button></a>
            </td>
         </tr>
      @endforeach
   </tbody>
</table>

<script>
    function delete_rows(id)
    {       
        if(confirm('Are you sure you want to delete this item?....'))
        {
            $.ajax(
            {
                url: 'employee/'+id,
                type: "DELETE",

                success: function (result)
                {
                    window.location.reload();
                }
            });
        }   
    }
</script>
  @else
  <p>Session expired please login again</p>
   <a href="{{url('/login')}}">Login</a>
@endif     
   </body>
</html>