<!doctype html>
<html>
   <head>
      <title>My Login Page</title>
   </head>
   <body>
      @if(session('message'))    
      <div class="alert">
      <span class="closebtn" onclick="this.parentElement.style.display='none';" style="color: red;font-size: 18px;">&times;</span> 
      <span style="color: red;font-size: 18px;"> {{ session('message')}}.</span>
      </div>
      @endif
      {{ Form::open(array('url' => 'login')) }}
      <h1>Login</h1>
      <!-- if there are login errors, show them here -->
      <p>
         {{ $errors->first('email') }}
         {{ $errors->first('password') }}
      </p>
      <p>
         <label>Email</label>
         
         <input type="text" name="email" placeholder="Enter your login mail id">
         <font color="red">
            <?php
               echo($errors->first('email',"<li class='error'>:message</li>"));
            ?>
         </font>
      </p>
      <p>
         <label>Password</label>
         <input type="password" name="password">
         <font color="red">
            <?php
               echo($errors->first('password',"<li class='error'>:message</li>"));
            ?>
         </font>
      </p>
      <p>{{ Form::submit('Submit!') }}</p>
      {{ Form::close() }}
   </body>
</html>