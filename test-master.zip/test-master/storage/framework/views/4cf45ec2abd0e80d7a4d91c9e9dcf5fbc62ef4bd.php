<!doctype html>
<html>
   <head>
      <title>My Login Page</title>
   </head>
   <body>
      <?php if(session('message')): ?>    
      <div class="alert">
      <span class="closebtn" onclick="this.parentElement.style.display='none';" style="color: red;font-size: 18px;">&times;</span> 
      <span style="color: red;font-size: 18px;"> <?php echo e(session('message')); ?>.</span>
      </div>
      <?php endif; ?>
      <?php echo e(Form::open(array('url' => 'login'))); ?>

      <h1>Login</h1>
      <!-- if there are login errors, show them here -->
      <p>
         <?php echo e($errors->first('email')); ?>

         <?php echo e($errors->first('password')); ?>

      </p>
      <p>
         <label>Email</label>
         
         <input type="text" name="email" placeholder="Enter your login mail id">
         <font color="red">
            <?php
               echo($errors->first('email',"<li class='error'>:message</li>"));
            ?>
         </font>
      </p>
      <p>
         <label>Password</label>
         <input type="password" name="password">
         <font color="red">
            <?php
               echo($errors->first('password',"<li class='error'>:message</li>"));
            ?>
         </font>
      </p>
      <p><?php echo e(Form::submit('Submit!')); ?></p>
      <?php echo e(Form::close()); ?>

   </body>
</html><?php /**PATH C:\xampp\htdocs\testProject\resources\views/login.blade.php ENDPATH**/ ?>