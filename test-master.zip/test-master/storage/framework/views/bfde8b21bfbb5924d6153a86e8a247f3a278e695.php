<!doctype html>
<html>
   <head>
      <title>Add employee</title>
   </head>
   <body>
      <?php if(session('message')): ?>    
      <div class="alert">
      <span class="closebtn" onclick="this.parentElement.style.display='none';" style="color: red;font-size: 18px;">&times;</span> 
      <span style="color: red;font-size: 18px;"> <?php echo e(session('message')); ?>.</span>
      </div>
      <?php endif; ?>
      <p>Enter employee details</p>
      <form action="<?php echo e(url('/employee/'.$findemployee->id)); ?>" method="PATCH">
         <?php echo e(csrf_field()); ?>

         <label>Name</label>
         <input type="text" name="name" value="<?php echo e($findemployee->name); ?>">
         <font color="red">
            <?php
               echo($errors->first('name',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Email Id</label>
         <input type="email" name="email" value="<?php echo e($findemployee->email); ?>">
         <font color="red">
            <?php
               echo($errors->first('email',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Mobile No</label>
         <input type="number" name="mobileno" value="<?php echo e($findemployee->mobileno); ?>">
         <font color="red">
            <?php
               echo($errors->first('mobileno',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Full Address</label>
         <textarea name="address"><?php echo e($findemployee->address); ?></textarea>
         <font color="red">
            <?php
               echo($errors->first('address',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Pincode</label>
         <input type="number" name="pincode" value="<?php echo e($findemployee->pincode); ?>">
         <font color="red">
            <?php
               echo($errors->first('pincode',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Salary</label>
         <input type="text" name="salary" value="<?php echo e($findemployee->salary); ?>">
         <font color="red">
            <?php
               echo($errors->first('salary',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <button type="submit" > Update</button>
         
      </form>

      <br><br>
      
   </body>
</html><?php /**PATH C:\xampp\htdocs\testProject\resources\views/showEmployee.blade.php ENDPATH**/ ?>