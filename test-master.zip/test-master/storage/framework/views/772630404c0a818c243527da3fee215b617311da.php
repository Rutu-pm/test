<!doctype html>
<html>
   <head>
      <title>Add employee</title>
   </head>
   <body>
   <?php if(Session::has('email')): ?>
      <?php if(session('message')): ?>    
      <div class="alert">
      <span class="closebtn" onclick="this.parentElement.style.display='none';" style="color: red;font-size: 18px;">&times;</span> 
      <span style="color: red;font-size: 18px;"> <?php echo e(session('message')); ?>.</span>
      </div>
      <?php endif; ?>
      <p>Enter employee details</p>
      <form action="<?php echo e(url('/employee')); ?>" method="POST">
         <?php echo e(csrf_field()); ?>

         <label>Name</label>
         <input type="text" name="name">
         <font color="red">
            <?php
               echo($errors->first('name',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Email Id</label>
         <input type="email" name="email">
         <font color="red">
            <?php
               echo($errors->first('email',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Mobile No</label>
         <input type="number" name="mobileno">
         <font color="red">
            <?php
               echo($errors->first('mobileno',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Full Address</label>
         <textarea name="address"></textarea>
         <font color="red">
            <?php
               echo($errors->first('address',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Pincode</label>
         <input type="number" name="pincode">
         <font color="red">
            <?php
               echo($errors->first('pincode',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <label>Salary</label>
         <input type="text" name="salary">
         <font color="red">
            <?php
               echo($errors->first('salary',"<li class='error'>:message</li>"));
            ?>
         </font>
         <br>
         <br>
         <button type="submit" > SAVE</button>
         
      </form>

      <br><br>
      <table class="table table-striped" >
   <thead>
      <tr>
         <td>Id</td>
         <td>Name</td>
         <td>Email</td>
         <td>Mobile No</td>
         <td>Salary</td>
         <td>Action</td>
      </tr>
   </thead>
   <tbody>
      <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($show->id); ?></td>
            <td><?php echo e($show->name); ?></td>
            <td><?php echo e($show->email); ?></td>
            <td><?php echo e($show->mobileno); ?></td>
            <td><?php echo e($show->salary); ?></td>
            <td>
               <a href="<?php echo e(url('/employee/'.$show->id)); ?>" ><button type="button">Edit</button></a>
               
               <a href="javascript:void(0)" onclick="delete_rows('<?php echo $show->id ?>')"><button type="button">Delete</button></a>
            </td>
         </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table>

<script>
    function delete_rows(id)
    {       
        if(confirm('Are you sure you want to delete this item?....'))
        {
            $.ajax(
            {
                url: 'employee/'+id,
                type: "DELETE",

                success: function (result)
                {
                    window.location.reload();
                }
            });
        }   
    }
</script>
  <?php else: ?>
   <a href="<?php echo e(url('/login')); ?>">Login</a>
<?php endif; ?>     
   </body>
</html><?php /**PATH C:\xampp\htdocs\testProject\resources\views/employee.blade.php ENDPATH**/ ?>