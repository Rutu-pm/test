<!doctype html>
<html>
   <head>
		<title>Login Successful</title>
   </head>
   <body>
   	<?php if(Session::has('email')): ?>
<p>Login Successful</p>
<?php echo $MyNavBar->asUl(); ?>


<?php else: ?>
<a href="<?php echo e(url('/login')); ?>">Login</a>
<?php endif; ?>

   



   </body>
</html><?php /**PATH C:\xampp\htdocs\testProject\resources\views/menu.blade.php ENDPATH**/ ?>